const JobRole = require('../models/job-role');
const mongoose = require('mongoose')


exports.getJobRole = ('/', (req, res, next) => {
    res.status(200).json({
        message:'this is Jobe role controller'
    })
    
  });

  exports.postJobRole = ('/', (req, res, next) => {
        const jobrole = new JobRole({
            _id: new mongoose.Types.ObjectId(),
            name:req.body.name,
        })

        jobrole.save()
        .then(result =>{
            console.log('this is result', result);
            res.status(200).json({
                message:'Create Record Successfully',
                createJobeRole:{
                    name: result.name,
                    _id: result._id,
                    request:{
                        type:"POST",
                        url:"http://localhost/3000/jobrole/" + result._id
                    }
                }
            })
        }).catch(err=>{
            console.log(err);
            res.status(500).json({
                error:err
            })

        })

   
})