const PayRole = require('../models/pay-role');
const mongoose = require('mongoose')


exports.getPayRole = ('/', (req, res, next) => {
    res.status(200).json({
        message:'this is pay role controller'
    })
    
  });

  exports.postPayRole = ('/', (req, res, next) => {
        const payrole = new PayRole({
            _id: new mongoose.Types.ObjectId(),
            employee:req.body.employee,
        })

        payrole.save()
        .then(result =>{
            console.log('this is result', result);
            res.status(200).json({
                message:'Create Record Successfully',
                createJobeRole:{
                    employee: result.employee,
                    _id: result._id,
                    request:{
                        type:"POST",
                        url:"http://localhost/3000/payrole/" + result._id
                    }
                }
            })
        }).catch(err=>{
            console.log(err);
            res.status(500).json({
                error:err
            })

        })

   
})