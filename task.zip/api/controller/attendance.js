const Attendance = require('../models/attendance');
const mongoose = require('mongoose')


exports.getAttendance = ('/', (req, res, next) => {
    res.status(200).json({
        message:'this is Addtandnce Controller'
    })
    
  });

  exports.postAttendance = ('/', (req, res, next) => {
        const attendance = new Attendance({
            _id: new mongoose.Types.ObjectId(),
            employee:req.body.employee,
            // check_in: req.body.check_in,
            // check_out: req.body.check_in
        })

        attendance.save()
        .then(result =>{
            console.log('this is result', result);
            res.status(200).json({
                message:'Create Record Successfully',
                createAttendance:{
                    employee: result.employee,
                    check_in: result.check_in,
                    check_out: result.check_out,
                    _id: result._id,
                    request:{
                        type:"POST",
                        url:"http://localhost/3000/attendance/" + result._id
                    }
                }
            })
        }).catch(err=>{
            console.log(err);
            res.status(500).json({
                error:err
            })

        })

   
})