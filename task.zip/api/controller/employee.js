const Emplyee = require('../models/employee');
const mongoose = require('mongoose')


exports.getEmplyee = ('/', (req, res, next) => {
   Emplyee.find().then(doc =>{
       console.log(doc);
       res.status(201).json(doc)
   }).catch(err =>{
       console.log(err);
       res.status(500).json({
           error:err
       })
   })
    
  });

  exports.postEmployee = ('/', (req, res, next) => {
        const employee = new Emplyee({
            _id: new mongoose.Types.ObjectId(),
            name: req.body.name,
            phone: req.body.phone
        })

        employee.save()
        .then(result =>{
            console.log(result);
            res.status(200).json({
                message:'Create Record Successfully',
                createEmployee:{
                    name: result.name,
                    phone: result.phone,
                    _id: result._id,
                    request:{
                        type:"POST",
                        url:"http://localhost/3000/employee/" + result._id
                    }
                }
            })
        }).catch(err=>{
            console.log(err);
            res.status(500).json({
                error:err
            })

        })

   
})