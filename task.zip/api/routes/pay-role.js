const path = require('path');

const express = require('express');

const payroleController = require('../controller/pay-role');

const router = express.Router();

router.get('/', payroleController.getPayRole);

router.post('/',payroleController.postPayRole)

module.exports = router ;
