const path = require('path');

const express = require('express');

const attendanceController = require('../controller/attendance');

const router = express.Router();

router.get('/', attendanceController.getAttendance);

router.post('/',attendanceController.postAttendance)

module.exports = router ;
