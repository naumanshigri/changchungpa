const path = require('path');

const express = require('express');

const employeeController = require('../controller/employee');

const router = express.Router();

router.get('/', employeeController.getEmplyee);

router.post('/',employeeController.postEmployee)

module.exports = router ;
