const path = require('path');

const express = require('express');

const jobroleController = require('../controller/job-role');

const router = express.Router();

router.get('/', jobroleController.getJobRole);

router.post('/',jobroleController.postJobRole)

module.exports = router ;
