const mongoose = require('mongoose')


const PayRoleSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    employee: {type:mongoose.Schema.Types.ObjectId, ref:'Employee', required:true},

})

module.exports = mongoose.model('PayRole', PayRoleSchema)