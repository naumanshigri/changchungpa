const mongoose = require('mongoose')


const employeeSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    name: {type:String, required:true},
    phone: {type:Number, required:true},
    jobRole: {type:mongoose.Schema.Types.ObjectId, ref:'JobRole'},

})

module.exports = mongoose.model('Employee', employeeSchema)