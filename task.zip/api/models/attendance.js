const mongoose = require('mongoose')


const attendanceSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    employee: {type:mongoose.Schema.Types.ObjectId, ref:'Employee', required:true},
    check_in : { type: Date },
    cehck_out : { type: Date }
})

module.exports = mongoose.model('Attendance', attendanceSchema)