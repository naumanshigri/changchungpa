const express = require('express');
const app = express()

const bodyParser = require('body-parser')   
const morgan = require('morgan')

const mongoose = require('mongoose')


const emplyeeRoute = require('./api/routes/employee')
const attendaneRoute = require('./api/routes/attendance')
const jobRoleRoute = require('./api/routes/job-role')
const payRoleRoute = require('./api/routes/pay-role')

mongoose.connect('mongodb+srv://user1:user1@cluster0.y0g8j.mongodb.net/task',{ useNewUrlParser: true , useNewUrlParser: true ,useUnifiedTopology: true })

mongoose.Promise = global.Promise
app.use(morgan('dev'))

app.use(bodyParser.urlencoded({extended:false}))
app.use(bodyParser.json())

app.use((req, res, next) =>{
    res.header('Access-Control-Allow-Origin', '*')
    res.header('Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept, Authorization')

    if(req.method === 'OPTIONS') {
        req.header('Access-Control-Allow-Methods', 'PUT, POST, PATCH, DELETE, GET')
        return res.status(200).json({})
    }
    next()
})

app.use('/employee', emplyeeRoute)
app.use('/attendance', attendaneRoute)
app.use('/jobrole', jobRoleRoute)
app.use('/payrole', payRoleRoute)


app.use((req, res, next) =>{
    const error = new Error('Not found')
    error.status = 404
    next(error)
})

app.use((error, req, res, next)=>{
    res.status(error.status || 500)
    res.json({
        error:{
            message:error.message
        }
    })
})
module.exports = app